# AMD GPU Provider Adapter
