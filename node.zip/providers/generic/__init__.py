# Generic providers (placeholder)
