# AMD providers
