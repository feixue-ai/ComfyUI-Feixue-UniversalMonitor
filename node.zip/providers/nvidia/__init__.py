# NVIDIA providers (placeholder)
